<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);
include 'koneksi.php';
$data = [
    [
        'jenis' => 'Gizi Berlebih'
    ],
    [
        'jenis' => 'Gizi Normal',
        'val' => 2,
    ]
];
